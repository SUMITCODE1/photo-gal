import React from "react"
import { Component } from "react"
import Title  from "./Title"
import PhotoWall from "./Photowall"
import AddPhoto from "./AddPhoto"
import { Route } from "react-router-dom"
import Single from "./Single"
import Tablayout from "./Tablayout"
import Fotter from "./Fotter"

class Main extends Component {

  constructor(){
    super();
  }

    render(){

    return (
      <div>

        <Title title={"Photos App"}/>

        <Route path="/" render={({history})=> (
          <Tablayout {...this.props} onHistory={history}/>
        )}/>

        <Route exact path="/" render={()=>(
           <div>
           <PhotoWall {...this.props} />
           </div>
        )}/>

        <Route path="/AddPhoto" render={({history})=> (
          <AddPhoto {...this.props} onHistory={history}/>
        )}/>

        <Route path="/single/:id" render={(params) => (
          <Single {...this.props} {...params}  />
        )}/>

        <Fotter></Fotter>

      </div>
    )
    }


}



export default Main