import Paper from "@material-ui/core/Paper";
import Tab from "@material-ui/core/Tab";
import Tabs from "@material-ui/core/Tabs";
import React from "react"
import {Component} from "react";
import { Link } from "react-router-dom";

class Tablayout extends Component{

      render(){
        return <div className="tabs-div">
         
          <Tabs className="tabs"
            onChange={(event, newValue) => {
              if(newValue===1)
              {
                this.props.onHistory.push('/AddPhoto')
                
              }else{
                this.props.onHistory.push('/')
              }
            }}
          >
            <Tab label="List Photos" />
            <Tab label="Construct photo"  />

          </Tabs>
         
        
      </div>
      }
    }


export default Tablayout