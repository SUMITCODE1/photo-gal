import React from "react"
import { Component } from "react"


function Title(props)
{
    return <h1>{props.title}</h1>
}

// class Title extends Component {
//     render(){
       
//     }
// }

export default Title