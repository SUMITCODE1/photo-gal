import React from "react";
import { Component } from "react";

class Fotter extends Component{

    render(){
        return <div id="fotter">
                
        <div class="col-1">
            <p>(c) copyright photos.com </p>
                <p>contact us for more info</p>
        </div>

    </div>
    }
}

export default Fotter