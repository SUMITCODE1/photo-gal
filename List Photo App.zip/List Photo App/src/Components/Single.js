import React from "react";
import { Component } from "react";  
import Photo from "./Photo";    
import Comments from "./Comments"
import {Link} from 'react-router-dom';

class Single extends Component {

    render() {
      const {match, posts} = this.props
      const id  = Number(match.params.id)
      const post = posts.find((post) => post.id === id)
      const comments = this.props.comments[id] || []
      const index = this.props.posts.findIndex((post)=> post.id === id)

        return <div className="single-photo">
           
            <Photo post={post} index={index} {...this.props}/>
            <Comments addComment={this.props.addComment} comments={comments} id={id}></Comments>
            <Link className="cross-icon" to="/"></Link> 
            </div>
    }
}

export default Single