import Main from "./Main"
import {connect} from 'react-redux'
import {bindActionCreators} from "redux"
import * as actions from "../Redux/actio9ns"
import {withRouter} from "react-router";

function mapStateToProp(state){
    return{
        posts:state.posts,
        comments:state.comments
    }
}

function mapDispatchToProps(dispatch)
{
    return bindActionCreators(actions,dispatch);
}

const App = withRouter(connect(mapStateToProp,mapDispatchToProps)(Main))

export default App