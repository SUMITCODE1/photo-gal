import React from "react";
import { Component } from "react";

class AddPhoto extends Component{

    constructor(){
        super();
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    handleSubmit(event){
        event.preventDefault();
      const imgLink = event.target.elements.link.value;
      const imgDesc = event.target.elements.desc.value;

      if(imgDesc!= null && imgLink!=null)
      {
          const post = {
              id: Number(new Date()),
              link: imgLink,
              desc:imgDesc
          }

          this.props.addPost(post);
          this.props.onHistory.push('/')
      }
    }

    render(){
        return (
            <div>
                      <h1>Construct your photo here</h1>

                      <div className="form">  
                      <form onSubmit={this.handleSubmit} >
                          <input type="text" placeholder="Link" name="link"/>
                          <input type="text" placeholder="Description" name="desc"/>
                          <button className="post-button"> Add Photo </button>
                      </form>
                      </div>
                      
            </div>
    
        )
    }
}

export default AddPhoto