const posts =  [{
    id:0,
    desc:"Hey This is b beautiful ladcscape",
    link : "https://th.bing.com/th/id/OIP.yLf7kQVaLpxqCZX1VRHw-wHaEK?pid=ImgDet&rs=1"
  },
  {
    id:1,
    desc:"Beaufiful Astral Photo",
    link : "https://i.pinimg.com/originals/ee/f1/54/eef15474431dd9aefe13a5675f9e4f83.jpg"
  },
  {
    id:2,
    desc:"Famus fantacy Series ",
    link : "https://th.bing.com/th/id/R.348d122d5b2d6f69b4b01d767044d826?rik=BjVu3J2QAOs7Kw&riu=http%3a%2f%2fcdn.collider.com%2fwp-content%2fuploads%2f2015%2f06%2fgame-of-thrones-night-king1.jpg&ehk=29JoAWHLtHQsfGyEToK7tiovm3VpFdELBBVGBONlsbQ%3d&risl=&pid=ImgRaw&r=0"
  }]

  export default posts;